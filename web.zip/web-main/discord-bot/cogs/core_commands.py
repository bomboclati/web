import os
import discord
from discord import app_commands
from discord.ext import commands
import logging
from data_manager import dm
from typing import List
import time

logger = logging.getLogger(__name__)

class CoreCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Model lists for each provider - Enhanced from bot.py
    COMMON_MODELS = [
        "llama-3.3-70b-versatile", "llama-3.3-8b-instant",
        "llama-3.2-1b-preview", "llama-3.2-3b-preview", "llama-3.2-11b-vision-preview", "llama-3.2-90b-vision-preview",
        "llama-3.1-8b-instant", "llama-guard-3-8b", "whisper-large-v3-turbo", "whisper-large-v3",
        "gemma2-9b-it", "gemma-7b-it", "mixtral-8x7b-32768",
        "qwen-2.5-coder-32b-instruct", "qwen-2.5-32b-instruct", "qwen-k1-0905",
        "mistral-saba-24b", "moonshot-v1-8k", "deepseek-r1-distill-qwen-32b",
        "meta-llama/llama-4-maverick-17b-128e-instruct-fp8", "meta-llama/llama-4-scout-17b-16e-instruct",
        "llama-3-groq-70b-tool-use-preview", "llama-3-groq-8b-tool-use-preview",
        "qwen3.6-plus", "qwen3.6-max", "qwen3.5-omni", "qwen-max-latest", "qwen-turbo-latest",
        "gemini-3.1-pro", "gemini-3.1-flash", "gemini-3.1-flash-lite", "gemini-3.1-flash-live",
        "gemini-3-pro", "gemini-3-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite",
        "gemini-2.0-flash", "gemini-1.5-pro", "gemini-1.5-flash",
        "gpt-5", "gpt-4o", "gpt-4o-mini", "o1", "o3-mini",
        "claude-3-5-sonnet", "claude-3-7-sonnet", "claude-4-opus",
        "llama-4-405b", "llama-3.1-405b",
        "google/gemini-3.1-pro", "deepseek/deepseek-v3", "meta-llama/llama-3.1-70b"
    ]

    MODEL_CHOICES = {
        "openrouter": ["openai/gpt-4o", "anthropic/claude-3.5-sonnet", "google/gemini-2.0-flash"],
        "openai": ["gpt-4o", "gpt-4o-mini", "o1", "o3-mini"],
        "gemini": ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
        "groq": ["llama-3.3-70b-versatile", "mixtral-8x7b-32768"],
        "mistral": ["mistral-large-latest", "mistral-medium-latest", "mistral-small-latest"],
        "deepseek": ["deepseek-chat", "deepseek-coder"],
        "anthropic": ["claude-3-5-sonnet-20240620", "claude-3-opus-20240229"],
        "dashscope": ["qwen-turbo", "qwen-plus", "qwen-max"]
    }

    def get_default_model(self, provider: str) -> str:
        """Get the default model for a provider"""
        defaults = {
            "openrouter": "openai/gpt-4o",
            "openai": "gpt-4o",
            "gemini": "gemini-2.5-pro",
            "groq": "llama-3.3-70b-versatile",
            "mistral": "mistral-large-latest",
            "deepseek": "deepseek-chat",
            "anthropic": "claude-3-5-sonnet-20240620",
            "dashscope": "qwen-turbo"
        }
        return defaults.get(provider, "gpt-4o-mini")

    config = app_commands.Group(name="config", description="Configure bot settings")

    async def config_model_autocomplete(self, interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
        """Autocomplete for model selection based on active provider"""
        # Get the guild's active provider
        current_config = dm.get_guild_api_key(interaction.guild.id) if interaction.guild else None
        provider = current_config.get("provider", "openrouter") if current_config else "openrouter"

        # Get models for this provider
        available_models = self.MODEL_CHOICES.get(provider, self.COMMON_MODELS)

        # Filter models based on current input
        filtered_models = [m for m in available_models if current.lower() in m.lower()]

        # Return up to 25 choices
        return [app_commands.Choice(name=model, value=model) for model in filtered_models[:25]]

    @config.command(name="model", description="Set the AI model")
    @app_commands.describe(model="Model name (e.g. gpt-4, claude-3)")
    @app_commands.autocomplete(model=config_model_autocomplete)
    async def config_model(self, interaction: discord.Interaction, model: str):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can change configuration.", ephemeral=True)
            return

        dm.update_guild_data(interaction.guild.id, "custom_model", model)
        await interaction.response.send_message(f"✅ AI model set to **{model}** for this server.", ephemeral=True)

    @config.command(name="provider", description="Set the active AI provider")
    @app_commands.choices(provider=[
        app_commands.Choice(name="OpenRouter (Universal)", value="openrouter"),
        app_commands.Choice(name="OpenAI", value="openai"),
        app_commands.Choice(name="Google Gemini", value="gemini"),
        app_commands.Choice(name="Groq (Ultra-Fast)", value="groq"),
        app_commands.Choice(name="Mistral AI", value="mistral"),
        app_commands.Choice(name="DeepSeek", value="deepseek"),
        app_commands.Choice(name="Anthropic", value="anthropic"),
        app_commands.Choice(name="Alibaba DashScope (Qwen)", value="dashscope")
    ])
    async def config_provider(self, interaction: discord.Interaction, provider: str):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can change configuration.", ephemeral=True)
            return

        dm.update_guild_data(interaction.guild.id, "active_provider", provider)
        # Reset custom_model to provider's default
        default_model = self.get_default_model(provider)
        dm.update_guild_data(interaction.guild.id, "custom_model", default_model)
        await interaction.response.send_message(f"✅ AI provider switched to **{provider}** and model reset to **{default_model}**.", ephemeral=True)

    @config.command(name="key", description="Set your own API key for a specific provider")
    @app_commands.choices(provider=[
        app_commands.Choice(name="OpenRouter", value="openrouter"),
        app_commands.Choice(name="OpenAI", value="openai"),
        app_commands.Choice(name="Gemini", value="gemini"),
        app_commands.Choice(name="Groq", value="groq"),
        app_commands.Choice(name="Mistral", value="mistral"),
        app_commands.Choice(name="DeepSeek", value="deepseek"),
        app_commands.Choice(name="Anthropic", value="anthropic"),
        app_commands.Choice(name="Alibaba DashScope (Qwen)", value="dashscope")
    ])
    @app_commands.describe(api_key="Your API key for this provider")
    async def config_key(self, interaction: discord.Interaction, provider: str, api_key: str):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can change configuration.", ephemeral=True)
            return
        
        dm.set_guild_api_key(interaction.guild.id, api_key, provider)
        await interaction.response.send_message(f"✅ API key for **{provider}** has been updated and encrypted.", ephemeral=True)

    @config.command(name="prefix", description="Set the server command prefix")
    @app_commands.describe(prefix="New prefix character (max 5 chars)")
    async def config_prefix(self, interaction: discord.Interaction, prefix: str):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can change configuration.", ephemeral=True)
            return
            
        if len(prefix) > 5:
            await interaction.response.send_message("❌ Prefix must be 5 characters or less.", ephemeral=True)
            return
            
        dm.update_guild_data(interaction.guild.id, "prefix", prefix)
        await interaction.response.send_message(f"✅ Server prefix set to **{prefix}**.", ephemeral=True)

    @config.command(name="sync", description="Force sync slash commands (Admin only)")
    async def config_sync(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can sync commands.", ephemeral=True)
            return
            
        await interaction.response.defer(ephemeral=True)
        try:
            await self.bot.tree.sync()
            await interaction.followup.send("✅ Slash commands synced successfully!", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Sync failed: {e}", ephemeral=True)

    @config.command(name="depth", description="Set memory depth")
    @app_commands.describe(depth="Number of messages to remember (5-100)")
    async def config_depth(self, interaction: discord.Interaction, depth: int):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can change configuration.", ephemeral=True)
            return
            
        if depth < 5 or depth > 100:
            await interaction.response.send_message("❌ Depth must be between 5 and 100.", ephemeral=True)
            return
            
        dm.update_guild_data(interaction.guild.id, "memory_depth", depth)
        await interaction.response.send_message(f"✅ Memory depth set to **{depth}**.", ephemeral=True)

    @app_commands.command(name="setup", description="Configure various systems")
    @app_commands.describe(system="Which system to setup")
    @app_commands.choices(
        system=[
            app_commands.Choice(name="Moderation System", value="moderation"),
            app_commands.Choice(name="Economy System", value="economy"),
            app_commands.Choice(name="Leveling System", value="leveling"),
            app_commands.Choice(name="Ticket System", value="tickets"),
            app_commands.Choice(name="Modmail System", value="modmail"),
            app_commands.Choice(name="Welcome/Goodbye", value="welcome"),
            app_commands.Choice(name="Auto-Setup Wizard", value="wizard")
        ]
    )
    async def setup_command(self, interaction: discord.Interaction, system: str = None):
        """Configure various systems"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can use setup commands.", ephemeral=True)
            return

        await interaction.response.defer()
        
        if system == "wizard" or not system:
            from modules.auto_setup import AutoSetup
            setup_helper = AutoSetup(self.bot)
            await setup_helper.autosetup(interaction)
        else:
            await interaction.followup.send(f"⚙️ Setting up {system} system...\n\n*This system is being initialized.*")

    @app_commands.command(name="disable", description="Disable a bot feature or scheduled task")
    @app_commands.describe(feature="Feature or task to disable")
    async def disable_command(self, interaction: discord.Interaction, feature: str):
        """Disable a feature or scheduled task"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Only Administrators can disable features.", ephemeral=True)
            return

        # Check for scheduled tasks
        tasks = dm.load_json("ai_scheduled_tasks", default={})
        if feature in tasks and tasks[feature].get("guild_id") == interaction.guild.id:
            tasks[feature]["enabled"] = False
            dm.save_json("ai_scheduled_tasks", tasks)
            await interaction.response.send_message(f"✅ Disabled scheduled task: **{feature}**", ephemeral=True)
            return

        # Check for generic modules
        modules = ["leveling", "economy", "starboard", "anti_raid", "auto_publisher", "auto_announcer", "welcome"]
        if feature.lower() in modules:
            dm.update_guild_data(interaction.guild.id, f"{feature.lower()}_enabled", False)
            await interaction.response.send_message(f"✅ Disabled module: **{feature}**", ephemeral=True)
            return

        await interaction.response.send_message(f"❌ Feature or task '**{feature}**' not found.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(CoreCommands(bot))
